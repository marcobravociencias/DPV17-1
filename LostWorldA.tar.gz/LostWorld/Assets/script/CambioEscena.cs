﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CambioEscena : MonoBehaviour {
	public Scene escena0;
	public Scene escena1;
	public Scene escena2;
	public Scene escena3;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter(Collider colision){
		SpriteRenderer jugador = colision.GetComponent<SpriteRenderer> ();

		if (jugador != null) {
			Application.LoadLevel (1);
		}
	}
}